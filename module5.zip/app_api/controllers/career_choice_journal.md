
    Trace the development of your career choice and plans for the future from your assignment into the Computer Science program until now.
    Write a journal entry that answers the following four questions and then complete the Status Checkpoints Table:

Part One:

    Have you changed your career plans? If so, what prompted this change? If not, why have you remained with your original plan?
    How has your thinking about your career evolved?
    Have you completed any research about your choice of career? How has this impacted your thinking? Have you thought about seeking an advanced degree or certification after earning your undergraduate degree?
    Which course outcomes have you achieved so far, and which ones remain?

Part Two:

Provide an update to your instructor on your progress with each category of artifacts for the ePortfolio:

    Software design and engineering
    Algorithms and data structures
    Databases
